This is the assignment 4 submission.

I create a EditText in xml file for users to enter phone number. When "send" button is pressed, the phone's location information(latitude and longitude) will be sent to the specific phone via SMS.

Latitude and longitude are obtained by using LocationManager. And using SmsManager to send message.

I use Nexus 5 API 21 for testing. First run the App, then, open Android Device Monitor, finally enter the phone number in emulator and press send button. 